get-childitem -path "assemblies" | foreach-object{
	set-variable -name "dirname" -value $_.Name
	get-childitem -path "assemblies\$dirname" | foreach-object{
		set-variable -name "object" -value $_.Name
		copy-item -path "assemblies\$dirname\$object" "C:\Windows\Microsoft.NET\assembly\GAC_MSIL\$dirname\$object" -recurse -force
	}
}